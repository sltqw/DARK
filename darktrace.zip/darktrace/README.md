# DARKTRACE

A dark, responsive OSINT and security utility dashboard built with FastAPI and vanilla JavaScript.

## Features

- Username availability search across public platforms
- IP, WHOIS, DNS, subdomain, HTTP header, SSL and website lookups
- Secure random password generator
- Bulk generator for up to 2,000 independent random passwords, with TXT export and copy
- Password strength checker
- Hash and Base64 tools
- Local/private network port scanner
- SQL injection and XSS learning references
- Global chat with server-assigned user IDs
- Chat displays usernames and IDs only; chat messages do not store or reveal sender IP addresses
- Responsive dark Liquid Glass interface
- Small `LICENSE` control at the bottom

## Password generation

Bulk passwords are cryptographically random and are not derived from a username or another person's identity. The generator is intended for creating new passwords, not guessing existing account credentials.

## Global chat

Chat identities are assigned by the server and remembered in the browser. Messages are stored in SQLite. The chat API does not save sender IP addresses in chat records and does not expose IP addresses to chat participants. The chat is a simple public room; add authentication, moderation, abuse controls and HTTPS before deploying it for a public audience.

## Run locally

```bash
python -m venv venv
# Windows:
venv\\Scripts\\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8000

API documentation: http://127.0.0.1:8000/api/docs

## Deployment

Set the host and port in `config.py` or environment variables as supported by the project. Use a persistent disk for the SQLite database. For public deployment, configure HTTPS, authentication, rate limiting, moderation and backups.

## License

Personal use. Do not use the tools to access accounts, systems or data without authorization.
