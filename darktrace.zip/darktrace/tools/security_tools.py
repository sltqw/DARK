"""
Cybersecurity educational tools.
All scanners restricted to localhost / authorized targets only.
"""
import socket
import hashlib
import re
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed

# Common ports for educational local scan
COMMON_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    5900: "VNC",
    6379: "Redis",
    8080: "HTTP-Alt",
    8443: "HTTPS-Alt",
    27017: "MongoDB",
}


def is_private_or_local(ip: str) -> bool:
    """Only allow scanning of private/local addresses."""
    if ip in ("127.0.0.1", "localhost", "::1"):
        return True
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    try:
        a, b, c, d = map(int, parts)
        if a == 10:
            return True
        if a == 172 and 16 <= b <= 31:
            return True
        if a == 192 and b == 168:
            return True
        if a == 127:
            return True
    except ValueError:
        return False
    return False


def port_scan_local(target: str = "127.0.0.1", ports: List[int] = None, timeout: float = 0.6) -> Dict[str, Any]:
    """
    Educational port scanner - STRICTLY limited to localhost / private IPs.
    Never scans public internet.
    """
    target = target.strip().lower()
    if target == "localhost":
        target = "127.0.0.1"

    if not is_private_or_local(target):
        return {
            "error": "Not allowed. Scanning is limited to localhost or private IP addresses. Public internet scanning is blocked.",
            "allowed": False,
        }

    if ports is None:
        ports = list(COMMON_PORTS.keys())

    open_ports = []
    closed = 0

    def check(port: int):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                result = s.connect_ex((target, port))
                if result == 0:
                    return port, True
        except Exception:
            pass
        return port, False

    with ThreadPoolExecutor(max_workers=30) as executor:
        futures = {executor.submit(check, p): p for p in ports}
        for fut in as_completed(futures):
            port, is_open = fut.result()
            if is_open:
                open_ports.append({
                    "port": port,
                    "service": COMMON_PORTS.get(port, "unknown"),
                })
            else:
                closed += 1

    open_ports.sort(key=lambda x: x["port"])
    return {
        "target": target,
        "open_ports": open_ports,
        "open_count": len(open_ports),
        "closed_count": closed,
        "note": "Educational local scanner only. For authorized testing.",
    }


def security_headers_analyze(headers: Dict[str, str]) -> Dict[str, Any]:
    """Analyze HTTP security headers (educational)."""
    findings = []
    score = 100

    checks = [
        ("strict-transport-security", "HSTS", "HSTS is missing — HTTPS is not enforced", 15),
        ("content-security-policy", "CSP", "Content-Security-Policy is missing", 20),
        ("x-frame-options", "X-Frame-Options", "Clickjacking protection is missing", 10),
        ("x-content-type-options", "X-Content-Type-Options", "MIME sniffing protection is missing", 10),
        ("referrer-policy", "Referrer-Policy", "Referrer Policy is missing", 5),
        ("permissions-policy", "Permissions-Policy", "Permissions-Policy is missing", 5),
        ("x-xss-protection", "X-XSS-Protection", "Legacy XSS Protection header (CSP is preferred)", 0),
    ]

    lower_headers = {k.lower(): v for k, v in headers.items()}

    for header, name, msg, penalty in checks:
        if header not in lower_headers:
            findings.append({"severity": name, "status": "missing", "message": msg, "severity": penalty})
            score -= penalty
        else:
            findings.append({"severity": name, "status": "present", "value": lower_headers[header][:80]})

    # Server header disclosure
    if "server" in lower_headers:
        findings.append({
            "severity": "Server",
            "status": "info",
            "message": f"Server header is exposed: {lower_headers['server'][:60]}",
            "severity": 5,
        })
        score -= 5

    score = max(0, min(100, score))
    level = "Good" if score >= 80 else "Fair" if score >= 50 else "Weak"

    return {
        "score": score,
        "level": level,
        "findings": findings,
    }


def sql_injection_learning() -> Dict[str, Any]:
    """Educational content + safe examples for SQL Injection awareness."""
    return {
        "title": "SQL Injection — Learning Resources",
        "warning": "For learning only. Unauthorized attacks against real systems are illegal.",
        "description": "SQL Injection occurs when untrusted input is directly concatenated into SQL queries, potentially allowing unintended database actions.",
        "vulnerable_example": "SELECT * FROM users WHERE username = '" + "{user_input}" + "' AND password = '" + "{pass_input}" + "'",
        "payloads_examples": [
            {"payload": "' OR '1'='1", "effect": "Makes the condition evaluate to true"},
            {"payload": "' OR 1=1 --", "effect": "Uses a comment to ignore the remaining query"},
            {"payload": "'; DROP TABLE users; --", "effect": "Deletes a table (destructive)"},
            {"payload": "' UNION SELECT null, username, password FROM users --", "effect": "Attempts to retrieve additional data"},
        ],
        "prevention": [
            "Use parameterized queries / prepared statements",
            "Use an ORM (SQLAlchemy, Django ORM)",
            "Never concatenate user input directly into SQL",
            "Follow the principle of least privilege",
            "Input validation + allowlist",
        ],
        "safe_code_python": """
# Vulnerable:
cursor.execute(f"SELECT * FROM users WHERE name = '{user_input}'")

# Safe:
cursor.execute("SELECT * FROM users WHERE name = ?", (user_input,))
# Or
cursor.execute("SELECT * FROM users WHERE name = %s", (user_input,))
""",
        "resources": [
            "https://owasp.org/www-community/attacks/SQL_Injection",
            "https://portswigger.net/web-security/sql-injection",
            "https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html",
        ],
    }


def xss_learning() -> Dict[str, Any]:
    """Educational content for Cross-Site Scripting."""
    return {
        "title": "XSS (Cross-Site Scripting) — Learning Resources",
        "warning": "For learning and testing systems you own or are authorized to assess. Attacking others’ websites is illegal.",
        "types": [
            {
                "name": "Reflected XSS",
                "desc": "User input is immediately reflected in the response (for example, through URL parameters).",
            },
            {
                "name": "Stored XSS",
                "desc": "A malicious script is stored and later shown to other users.",
            },
            {
                "name": "DOM-based XSS",
                "desc": "The DOM is modified through client-side JavaScript.",
            },
        ],
        "examples": [
            {"payload": "<script>alert(1)</script>", "context": "HTML body"},
            {"payload": "\" onmouseover=\"alert(1)", "context": "Attribute injection"},
            {"payload": "javascript:alert(1)", "context": "URL / href"},
            {"payload": "<img src=x onerror=alert(1)>", "context": "Image tag"},
        ],
        "prevention": [
            "Output encoding / escaping (context-aware)",
            "Content-Security-Policy (CSP) header",
            "HttpOnly + Secure cookies",
            "Use framework auto-escaping features (React, Vue, Jinja2 autoescape)",
            "Sanitize HTML (DOMPurify)",
        ],
        "resources": [
            "https://owasp.org/www-community/attacks/xss/",
            "https://portswigger.net/web-security/cross-site-scripting",
            "https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html",
        ],
    }


def generate_uuid() -> Dict[str, str]:
    import uuid
    return {
        "uuid4": str(uuid.uuid4()),
        "uuid1": str(uuid.uuid1()),
    }
