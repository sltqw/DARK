"""
Cryptographic and encoding tools - fully local, no external calls.
"""
import hashlib
import base64
import secrets
import string
import re
from typing import Dict, Any, List

# Common hash identifiers
HASH_SIGNATURES = {
    "md5": {"length": 32, "charset": r"^[a-fA-F0-9]{32}$"},
    "sha1": {"length": 40, "charset": r"^[a-fA-F0-9]{40}$"},
    "sha224": {"length": 56, "charset": r"^[a-fA-F0-9]{56}$"},
    "sha256": {"length": 64, "charset": r"^[a-fA-F0-9]{64}$"},
    "sha384": {"length": 96, "charset": r"^[a-fA-F0-9]{96}$"},
    "sha512": {"length": 128, "charset": r"^[a-fA-F0-9]{128}$"},
    "ntlm": {"length": 32, "charset": r"^[a-fA-F0-9]{32}$"},  # same as md5 visually
    "bcrypt": {"length": 60, "charset": r"^\$2[aby]?\$\d{2}\$[./A-Za-z0-9]{53}$"},
    "argon2": {"length": None, "charset": r"^\$argon2(id|i|d)\$"},
}


def generate_password(
    length: int = 16,
    use_upper: bool = True,
    use_lower: bool = True,
    use_digits: bool = True,
    use_symbols: bool = True,
    exclude_ambiguous: bool = True,
) -> str:
    if length < 4:
        length = 4
    if length > 128:
        length = 128

    chars = ""
    if use_lower:
        chars += string.ascii_lowercase
    if use_upper:
        chars += string.ascii_uppercase
    if use_digits:
        chars += string.digits
    if use_symbols:
        chars += "!@#$%^&*()-_=+[]{}|;:,.<>?"

    if exclude_ambiguous:
        for c in "Il1O0":
            chars = chars.replace(c, "")

    if not chars:
        chars = string.ascii_letters + string.digits

    return "".join(secrets.choice(chars) for _ in range(length))


def check_password_strength(password: str) -> Dict[str, Any]:
    score = 0
    feedback = []
    length = len(password)

    if length >= 12:
        score += 25
    elif length >= 8:
        score += 15
    else:
        feedback.append("Use at least 12 characters")

    has_lower = bool(re.search(r"[a-z]", password))
    has_upper = bool(re.search(r"[A-Z]", password))
    has_digit = bool(re.search(r"\d", password))
    has_symbol = bool(re.search(r"[^a-zA-Z0-9]", password))

    if has_lower:
        score += 15
    else:
        feedback.append("Add lowercase letters")
    if has_upper:
        score += 15
    else:
        feedback.append("Add uppercase letters")
    if has_digit:
        score += 15
    else:
        feedback.append("Add numbers")
    if has_symbol:
        score += 20
    else:
        feedback.append("Add special characters")

    # Entropy-ish bonus
    unique = len(set(password))
    if unique > length * 0.7:
        score += 10

    # Common patterns penalty
    common = ["123456", "password", "qwerty", "admin", "111111", "abc123"]
    lower_p = password.lower()
    for c in common:
        if c in lower_p:
            score = max(0, score - 30)
            feedback.append(f"Common pattern detected: {c}")

    if score >= 80:
        level = "Very strong"
        color = "green"
    elif score >= 60:
        level = "Strong"
        color = "lime"
    elif score >= 40:
        level = "Medium"
        color = "yellow"
    elif score >= 20:
        level = "Weak"
        color = "orange"
    else:
        level = "Very weak"
        color = "red"

    return {
        "score": min(100, score),
        "level": level,
        "color": color,
        "length": length,
        "has_lower": has_lower,
        "has_upper": has_upper,
        "has_digit": has_digit,
        "has_symbol": has_symbol,
        "feedback": feedback,
    }


def generate_hash(text: str, algorithm: str = "sha256") -> Dict[str, str]:
    algo = algorithm.lower().strip()
    data = text.encode("utf-8")

    result = {"input": text, "algorithm": algo}

    if algo == "md5":
        result["hash"] = hashlib.md5(data).hexdigest()
    elif algo == "sha1":
        result["hash"] = hashlib.sha1(data).hexdigest()
    elif algo == "sha224":
        result["hash"] = hashlib.sha224(data).hexdigest()
    elif algo == "sha256":
        result["hash"] = hashlib.sha256(data).hexdigest()
    elif algo == "sha384":
        result["hash"] = hashlib.sha384(data).hexdigest()
    elif algo == "sha512":
        result["hash"] = hashlib.sha512(data).hexdigest()
    elif algo == "blake2b":
        result["hash"] = hashlib.blake2b(data).hexdigest()
    elif algo == "blake2s":
        result["hash"] = hashlib.blake2s(data).hexdigest()
    else:
        # generate several
        result["md5"] = hashlib.md5(data).hexdigest()
        result["sha1"] = hashlib.sha1(data).hexdigest()
        result["sha256"] = hashlib.sha256(data).hexdigest()
        result["sha512"] = hashlib.sha512(data).hexdigest()
        result["algorithm"] = "multi"

    return result


def identify_hash(hash_str: str) -> List[Dict[str, Any]]:
    hash_str = hash_str.strip()
    candidates = []

    for name, sig in HASH_SIGNATURES.items():
        if sig["charset"] and re.match(sig["charset"], hash_str):
            if sig["length"] is None or len(hash_str) == sig["length"]:
                candidates.append({
                    "type": name.upper(),
                    "confidence": "high" if name != "ntlm" else "medium",
                    "length": len(hash_str),
                })

    if not candidates:
        # fallback length based
        length = len(hash_str)
        if length == 32:
            candidates.append({"type": "MD5 / NTLM / MD4", "confidence": "medium", "length": 32})
        elif length == 40:
            candidates.append({"type": "SHA-1", "confidence": "high", "length": 40})
        elif length == 64:
            candidates.append({"type": "SHA-256", "confidence": "high", "length": 64})
        else:
            candidates.append({"type": "Unknown", "confidence": "low", "length": length})

    return candidates


def base64_encode(text: str) -> str:
    return base64.b64encode(text.encode("utf-8")).decode("ascii")


def base64_decode(text: str) -> Dict[str, Any]:
    try:
        # clean padding
        text = text.strip()
        missing = len(text) % 4
        if missing:
            text += "=" * (4 - missing)
        decoded = base64.b64decode(text).decode("utf-8")
        return {"success": True, "result": decoded}
    except Exception as e:
        return {"success": False, "error": str(e)}


def generate_totp_secret() -> Dict[str, str]:
    import pyotp
    secret = pyotp.random_base32()
    totp = pyotp.TOTP(secret)
    return {
        "secret": secret,
        "uri": totp.provisioning_uri(name="DARKTRACE", issuer_name="DARKTRACE"),
        "current_code": totp.now(),
    }
