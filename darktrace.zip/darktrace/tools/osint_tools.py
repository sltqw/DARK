"""
OSINT tools - public data only. Educational / authorized use.
"""
import asyncio
import re
import socket
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse
import httpx
import dns.resolver
import whois
from config import USERNAME_PLATFORMS, IPINFO_TOKEN

# User-Agent for polite requests
UA = "DARKTRACE-OSINT/1.0 (Educational Platform; +https://localhost)"


async def check_username(username: str, platforms: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """
    Check username availability across curated public platforms.
    Returns list of results with status (found / not_found / error / unknown).
    """
    username = username.strip().lstrip("@")
    if not username or len(username) > 64 or not re.match(r"^[\w.\-]+$", username):
        return [{"error": "Invalid username format"}]

    targets = USERNAME_PLATFORMS
    if platforms:
        targets = [p for p in USERNAME_PLATFORMS if p["name"] in platforms]

    results = []
    async with httpx.AsyncClient(
        timeout=8.0,
        follow_redirects=True,
        headers={"User-Agent": UA},
    ) as client:
        tasks = []
        for p in targets:
            tasks.append(_check_one_platform(client, username, p))
        results = await asyncio.gather(*tasks, return_exceptions=True)

    clean = []
    for r in results:
        if isinstance(r, Exception):
            clean.append({"platform": "?", "status": "error", "error": str(r)})
        else:
            clean.append(r)
    return clean


async def _check_one_platform(client: httpx.AsyncClient, username: str, platform: Dict) -> Dict[str, Any]:
    url = platform["url"].format(username)
    result = {
        "platform": platform["name"],
        "username": username,
        "url": url,
        "icon": platform.get("icon", "globe"),
        "status": "unknown",
    }
    try:
        if platform.get("check") == "manual":
            result["status"] = "manual"
            result["note"] = "Manual verification required"
            return result

        resp = await client.head(url) if platform["name"] not in ["Instagram", "TikTok"] else await client.get(url)
        # Many platforms return 200 even for missing, or 404 for missing.
        # Heuristic:
        if resp.status_code == 404:
            result["status"] = "not_found"
        elif resp.status_code in (200, 301, 302, 303):
            # Additional soft checks for some sites
            if platform["name"] == "GitHub" and "Not Found" in (resp.text or ""):
                result["status"] = "not_found"
            else:
                result["status"] = "found"
        elif resp.status_code == 429:
            result["status"] = "rate_limited"
        else:
            result["status"] = "unknown"
            result["http_code"] = resp.status_code
    except httpx.TimeoutException:
        result["status"] = "timeout"
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)[:120]
    return result


async def multi_username_search(usernames: List[str]) -> Dict[str, List[Dict]]:
    """Search multiple usernames in parallel (limited concurrency)."""
    usernames = [u.strip().lstrip("@") for u in usernames if u.strip()][:10]  # safety limit
    results = {}
    for u in usernames:
        results[u] = await check_username(u)
    return results


async def ip_lookup(ip: str) -> Dict[str, Any]:
    """Geolocation + basic info via free public APIs."""
    ip = ip.strip()
    if not re.match(r"^(\d{1,3}\.){3}\d{1,3}$", ip) and ":" not in ip:
        return {"error": "Invalid IP address"}

    data = {"ip": ip, "source": []}

    # 1. ip-api.com (no key, non-commercial, HTTP)
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            r = await client.get(f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,asname,query,mobile,proxy,hosting")
            if r.status_code == 200:
                j = r.json()
                if j.get("status") == "success":
                    data.update({
                        "country": j.get("country"),
                        "country_code": j.get("countryCode"),
                        "region": j.get("regionName"),
                        "city": j.get("city"),
                        "zip": j.get("zip"),
                        "lat": j.get("lat"),
                        "lon": j.get("lon"),
                        "timezone": j.get("timezone"),
                        "isp": j.get("isp"),
                        "org": j.get("org"),
                        "as": j.get("as"),
                        "asname": j.get("asname"),
                        "mobile": j.get("mobile"),
                        "proxy": j.get("proxy"),
                        "hosting": j.get("hosting"),
                    })
                    data["source"].append("ip-api.com")
    except Exception as e:
        data["ip_api_error"] = str(e)[:100]

    # 2. Optional IPinfo if token present
    if IPINFO_TOKEN:
        try:
            async with httpx.AsyncClient(timeout=6.0) as client:
                r = await client.get(
                    f"https://ipinfo.io/{ip}/json",
                    headers={"Authorization": f"Bearer {IPINFO_TOKEN}"},
                )
                if r.status_code == 200:
                    j = r.json()
                    data["ipinfo"] = j
                    data["source"].append("ipinfo.io")
        except Exception:
            pass

    # Reverse DNS
    try:
        host = socket.gethostbyaddr(ip)[0]
        data["reverse_dns"] = host
    except Exception:
        data["reverse_dns"] = None

    return data


async def domain_whois(domain: str) -> Dict[str, Any]:
    domain = domain.strip().lower()
    domain = re.sub(r"^https?://", "", domain).split("/")[0]
    if not domain or "." not in domain:
        return {"error": "Invalid domain"}

    result = {"domain": domain}
    try:
        w = whois.whois(domain)
        result["registrar"] = str(w.registrar) if w.registrar else None
        result["creation_date"] = str(w.creation_date) if w.creation_date else None
        result["expiration_date"] = str(w.expiration_date) if w.expiration_date else None
        result["updated_date"] = str(w.updated_date) if w.updated_date else None
        result["name_servers"] = list(w.name_servers) if w.name_servers else []
        result["status"] = list(w.status) if w.status else []
        result["emails"] = list(w.emails) if w.emails else []
        result["org"] = str(w.org) if w.org else None
        result["country"] = str(w.country) if w.country else None
        result["raw"] = str(w)[:2000]
    except Exception as e:
        result["error"] = str(e)
    return result


async def dns_lookup(domain: str, record_type: str = "A") -> Dict[str, Any]:
    domain = domain.strip().lower().rstrip(".")
    record_type = record_type.upper()
    allowed = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "PTR"]
    if record_type not in allowed:
        record_type = "A"

    result = {"domain": domain, "type": record_type, "records": []}
    try:
        answers = dns.resolver.resolve(domain, record_type)
        for rdata in answers:
            result["records"].append(str(rdata))
    except dns.resolver.NXDOMAIN:
        result["error"] = "Domain does not exist (NXDOMAIN)"
    except dns.resolver.NoAnswer:
        result["error"] = "No records of this type"
    except Exception as e:
        result["error"] = str(e)
    return result


async def subdomain_discovery(domain: str) -> Dict[str, Any]:
    """
    Lightweight educational subdomain check using common wordlist + DNS.
    Not a full scanner - for learning only.
    """
    domain = domain.strip().lower().rstrip(".")
    common = [
        "www", "mail", "ftp", "webmail", "smtp", "pop", "ns1", "ns2",
        "blog", "dev", "staging", "api", "admin", "portal", "cdn",
        "test", "demo", "app", "m", "mobile", "shop", "store",
        "vpn", "remote", "git", "gitlab", "ci", "status", "docs",
    ]
    found = []
    async with httpx.AsyncClient(timeout=4.0) as client:
        for sub in common:
            host = f"{sub}.{domain}"
            try:
                answers = dns.resolver.resolve(host, "A")
                ips = [str(r) for r in answers]
                found.append({"subdomain": host, "ips": ips})
            except Exception:
                pass
    return {"domain": domain, "found": found, "checked": len(common), "note": "Educational wordlist only. Use Amass/Subfinder for real recon."}


async def http_headers(url: str) -> Dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True, headers={"User-Agent": UA}) as client:
            r = await client.get(url)
            return {
                "url": str(r.url),
                "status_code": r.status_code,
                "headers": dict(r.headers),
                "redirects": len(r.history),
            }
    except Exception as e:
        return {"error": str(e)}


async def ssl_check(hostname: str) -> Dict[str, Any]:
    import ssl
    hostname = hostname.strip().lower()
    hostname = re.sub(r"^https?://", "", hostname).split("/")[0]
    try:
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=8) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                return {
                    "hostname": hostname,
                    "subject": dict(x[0] for x in cert.get("subject", ())),
                    "issuer": dict(x[0] for x in cert.get("issuer", ())),
                    "version": cert.get("version"),
                    "serialNumber": cert.get("serialNumber"),
                    "notBefore": cert.get("notBefore"),
                    "notAfter": cert.get("notAfter"),
                    "subjectAltName": cert.get("subjectAltName", []),
                }
    except Exception as e:
        return {"error": str(e)}


async def website_analyzer(url: str) -> Dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        async with httpx.AsyncClient(timeout=12.0, follow_redirects=True, headers={"User-Agent": UA}) as client:
            r = await client.get(url)
            text = r.text[:50000]
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(text, "lxml")
            title = soup.title.string if soup.title else None
            meta_desc = ""
            for m in soup.find_all("meta"):
                if m.get("name", "").lower() == "description":
                    meta_desc = m.get("content", "")
                    break
            links = len(soup.find_all("a"))
            images = len(soup.find_all("img"))
            scripts = len(soup.find_all("script"))
            return {
                "url": str(r.url),
                "status": r.status_code,
                "title": title,
                "description": meta_desc[:300],
                "links_count": links,
                "images_count": images,
                "scripts_count": scripts,
                "server": r.headers.get("server"),
                "content_type": r.headers.get("content-type"),
                "content_length": r.headers.get("content-length"),
            }
    except Exception as e:
        return {"error": str(e)}
