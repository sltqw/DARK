/* DARKTRACE Frontend Logic */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function toast(msg, type = "success") {
  const el = document.createElement("div");
  el.className = `toast toast-${type}`;
  el.textContent = msg;
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

function setLoading(btn, on) {
  if (!btn) return;
  if (on) {
    btn.disabled = true;
    btn.dataset.old = btn.innerHTML;
    btn.innerHTML = `<div class="spinner"></div>`;
  } else {
    btn.disabled = false;
    if (btn.dataset.old) btn.innerHTML = btn.dataset.old;
  }
}

async function api(path, method = "GET", body = null) {
  const opts = {
    method,
    headers: { "Content-Type": "application/json" },
  };
  if (body) opts.body = JSON.stringify(body);
  try {
    const r = await fetch(path, opts);
    const data = await r.json();
    if (!r.ok) throw new Error(data.detail || data.error || "Error");
    return data;
  } catch (e) {
    toast(e.message || "Network error", "error");
    throw e;
  }
}

/* Navigation */
function showPanel(id) {
  $$(".panel").forEach((p) => p.classList.remove("active"));
  $$(".nav-item").forEach((n) => n.classList.remove("active"));
  $$(".bottom-nav-item").forEach((n) => n.classList.remove("active"));

  const panel = $(`#panel-${id}`);
  if (panel) panel.classList.add("active");

  $$(`[data-panel="${id}"]`).forEach((el) => el.classList.add("active"));

  const titles = {
    dashboard: "Dashboard",
    username: "Username Search",
    "multi-username": "Multi Search",
    ip: "IP Lookup",
    whois: "WHOIS",
    dns: "DNS Lookup",
    subdomain: "Subdomains",
    headers: "HTTP Headers",
    ssl: "SSL Checker",
    analyze: "Website Analyzer",
    password: "Password Tools",
    chat: "Global Chat",
    hash: "Hash Tools",
    base64: "Base64",
    portscan: "Port Scanner",
    learn: "Learning Lab",
  };
  $("#topTitle").textContent = titles[id] || id;

  // close mobile sidebar
  $("#sidebar").classList.remove("open");
  $("#sidebarOverlay").classList.remove("open");
}

$$(".nav-item, .bottom-nav-item").forEach((btn) => {
  btn.addEventListener("click", () => showPanel(btn.dataset.panel));
});

$("#menuBtn")?.addEventListener("click", () => {
  $("#sidebar").classList.toggle("open");
  $("#sidebarOverlay").classList.toggle("open");
});
$("#sidebarOverlay")?.addEventListener("click", () => {
  $("#sidebar").classList.remove("open");
  $("#sidebarOverlay").classList.remove("open");
});

/* Dashboard */
async function loadDashboard() {
  try {
    const d = await api("/api/dashboard");
    $("#statTotal").textContent = d.total_tools;
    $("#statOsint").textContent = d.osint_tools;
    $("#statCyber").textContent = d.cyber_tools;

    const box = $("#recentActivity");
    if (d.recent_activity && d.recent_activity.length) {
      box.innerHTML = d.recent_activity
        .map(
          (a) => `
        <div style="padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.05);display:flex;justify-content:space-between;gap:12px">
          <div>
            <div style="font-weight:600;font-size:14px">${escapeHtml(a.tool)}</div>
            <div class="text-sm text-secondary">${escapeHtml(a.query || "")}</div>
          </div>
          <div class="text-sm text-secondary" style="white-space:nowrap">${a.created_at || ""}</div>
        </div>`
        )
        .join("");
    }
  } catch (_) {}
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderJson(obj) {
  return `<div class="code-block">${escapeHtml(JSON.stringify(obj, null, 2))}</div>`;
}

function badge(status) {
  const map = {
    found: ["badge-found", "Found"],
    not_found: ["badge-not", "Not found"],
    unknown: ["badge-unknown", "Unknown"],
    manual: ["badge-manual", "Manual"],
    timeout: ["badge-unknown", "Timeout"],
    error: ["badge-not", "Error"],
    rate_limited: ["badge-manual", "Rate limit"],
  };
  const [cls, text] = map[status] || ["badge-unknown", status];
  return `<span class="badge ${cls}">${text}</span>`;
}

/* Username */
async function runUsernameSearch() {
  const username = $("#usernameInput").value.trim();
  if (!username) return toast("Enter a username", "error");
  const btn = $("#btnUsername");
  setLoading(btn, true);
  const box = $("#usernameResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div> Searching...</div>`;
  try {
    const data = await api("/api/username/search", "POST", { username });
    if (!data.results || !data.results.length) {
      box.innerHTML = `<div class="glass-card result-card">No results</div>`;
      return;
    }
    box.innerHTML = data.results
      .map(
        (r) => `
      <div class="glass-card result-card">
        <div class="result-icon">${r.icon ? r.icon[0].toUpperCase() : "🌐"}</div>
        <div class="result-body">
          <div class="result-title">${escapeHtml(r.platform)}</div>
          <div class="result-sub mono">${escapeHtml(r.url || "")}</div>
        </div>
        ${badge(r.status)}
        ${
          r.status === "found"
            ? `<a class="btn btn-glass btn-sm" href="${escapeHtml(r.url)}" target="_blank" rel="noopener">Open</a>
               <button class="btn btn-glass btn-sm" onclick="navigator.clipboard.writeText('${escapeHtml(r.url)}');toast('Copied')">Copy</button>`
            : ""
        }
      </div>`
      )
      .join("");
    toast(`Found: ${data.found_count}`);
  } catch (e) {
    box.innerHTML = "";
  } finally {
    setLoading(btn, false);
  }
}

async function runMultiUsername() {
  const raw = $("#multiUsernames").value.trim();
  if (!raw) return toast("Enter usernames", "error");
  const usernames = raw.split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
  const box = $("#multiResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div> Multi search...</div>`;
  try {
    const data = await api("/api/username/multi", "POST", { usernames });
    let html = "";
    for (const [user, results] of Object.entries(data.results || {})) {
      const found = results.filter((r) => r.status === "found").length;
      html += `<div class="glass-card" style="padding:16px;margin-bottom:12px">
        <div style="font-weight:700;margin-bottom:10px">@${escapeHtml(user)} — ${found} found</div>
        ${results
          .filter((r) => r.status === "found")
          .map(
            (r) =>
              `<div class="flex items-center justify-between" style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
                <span>${escapeHtml(r.platform)}</span>
                <a class="text-sm" style="color:var(--accent)" href="${escapeHtml(r.url)}" target="_blank">Open</a>
              </div>`
          )
          .join("")}
      </div>`;
    }
    box.innerHTML = html || "No results";
  } catch (e) {
    box.innerHTML = "";
  }
}

/* IP */
async function runIpLookup() {
  const ip = $("#ipInput").value.trim();
  if (!ip) return toast("Enter an IP address", "error");
  const box = $("#ipResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/ip/lookup", "POST", { ip });
    if (d.error) {
      box.innerHTML = `<div class="glass-card result-card">${escapeHtml(d.error)}</div>`;
      return;
    }
    box.innerHTML = `
      <div class="glass-card" style="padding:20px">
        <div style="font-size:22px;font-weight:700;margin-bottom:12px">${escapeHtml(d.ip)}</div>
        <div class="grid" style="grid-template-columns:1fr 1fr;gap:10px">
          <div><div class="text-sm text-secondary">Country</div><div>${escapeHtml(d.country || "—")} (${escapeHtml(d.country_code || "")})</div></div>
          <div><div class="text-sm text-secondary">City</div><div>${escapeHtml(d.city || "—")}</div></div>
          <div><div class="text-sm text-secondary">Region</div><div>${escapeHtml(d.region || "—")}</div></div>
          <div><div class="text-sm text-secondary">ISP</div><div>${escapeHtml(d.isp || "—")}</div></div>
          <div><div class="text-sm text-secondary">Org</div><div>${escapeHtml(d.org || "—")}</div></div>
          <div><div class="text-sm text-secondary">ASN</div><div>${escapeHtml(d.as || "—")}</div></div>
          <div><div class="text-sm text-secondary">Timezone</div><div>${escapeHtml(d.timezone || "—")}</div></div>
          <div><div class="text-sm text-secondary">Coords</div><div>${d.lat ?? "—"}, ${d.lon ?? "—"}</div></div>
          <div><div class="text-sm text-secondary">Proxy</div><div>${d.proxy ? "Yes" : "No"}</div></div>
          <div><div class="text-sm text-secondary">Hosting</div><div>${d.hosting ? "Yes" : "No"}</div></div>
          <div><div class="text-sm text-secondary">Reverse DNS</div><div class="mono">${escapeHtml(d.reverse_dns || "—")}</div></div>
        </div>
      </div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* WHOIS */
async function runWhois() {
  const domain = $("#whoisInput").value.trim();
  if (!domain) return toast("Enter a domain", "error");
  const box = $("#whoisResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/domain/whois", "POST", { domain });
    box.innerHTML = `<div class="glass-card" style="padding:20px">${renderJson(d)}</div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* DNS */
async function runDns() {
  const domain = $("#dnsDomain").value.trim();
  const type = $("#dnsType").value;
  if (!domain) return toast("Enter a domain", "error");
  const box = $("#dnsResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/domain/dns", "POST", { domain, type });
    if (d.error) {
      box.innerHTML = `<div class="glass-card result-card">${escapeHtml(d.error)}</div>`;
      return;
    }
    box.innerHTML = `
      <div class="glass-card" style="padding:20px">
        <div style="font-weight:600;margin-bottom:10px">${escapeHtml(d.domain)} · ${escapeHtml(d.type)}</div>
        ${(d.records || []).map((r) => `<div class="code-block" style="margin-bottom:6px">${escapeHtml(r)}</div>`).join("") || "No records found"}
      </div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* Subdomains */
async function runSubdomains() {
  const domain = $("#subDomain").value.trim();
  if (!domain) return toast("Enter a domain", "error");
  const box = $("#subResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div> Educational scan...</div>`;
  try {
    const d = await api("/api/domain/subdomains", "POST", { domain });
    if (!d.found || !d.found.length) {
      box.innerHTML = `<div class="glass-card result-card">No subdomains found (limited wordlist)</div>`;
      return;
    }
    box.innerHTML = d.found
      .map(
        (s) => `
      <div class="glass-card result-card">
        <div class="result-body">
          <div class="result-title mono">${escapeHtml(s.subdomain)}</div>
          <div class="result-sub">${(s.ips || []).join(", ")}</div>
        </div>
      </div>`
      )
      .join("");
  } catch (e) {
    box.innerHTML = "";
  }
}

/* Headers */
async function runHeaders() {
  const url = $("#headersUrl").value.trim();
  if (!url) return toast("Enter a URL", "error");
  const box = $("#headersResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/url/headers", "POST", { url });
    if (d.error) {
      box.innerHTML = `<div class="glass-card result-card">${escapeHtml(d.error)}</div>`;
      return;
    }
    let rows = Object.entries(d.headers || {})
      .map(([k, v]) => `<tr><td style="padding:6px 10px;color:var(--text-secondary);vertical-align:top">${escapeHtml(k)}</td><td style="padding:6px 10px;word-break:break-all">${escapeHtml(v)}</td></tr>`)
      .join("");
    box.innerHTML = `
      <div class="glass-card" style="padding:20px">
        <div style="margin-bottom:12px">Status: <strong>${d.status_code}</strong> · ${escapeHtml(d.url || "")}</div>
        <table style="width:100%;font-size:13px">${rows}</table>
      </div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* SSL */
async function runSsl() {
  const host = $("#sslHost").value.trim();
  if (!host) return toast("Enter a hostname", "error");
  const box = $("#sslResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/url/ssl", "POST", { domain: host });
    box.innerHTML = `<div class="glass-card" style="padding:20px">${renderJson(d)}</div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* Analyze */
async function runAnalyze() {
  const url = $("#analyzeUrl").value.trim();
  if (!url) return toast("Enter a URL", "error");
  const box = $("#analyzeResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api("/api/url/analyze", "POST", { url });
    box.innerHTML = `<div class="glass-card" style="padding:20px">${renderJson(d)}</div>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

/* Password */
async function runPasswordGen() {
  const body = {
    length: parseInt($("#pwdLen").value, 10),
    use_upper: $("#pwdUpper").checked,
    use_lower: $("#pwdLower").checked,
    use_digits: $("#pwdDigit").checked,
    use_symbols: $("#pwdSymbol").checked,
  };
  try {
    const d = await api("/api/password/generate", "POST", body);
    $("#pwdResult").innerHTML = `
      <div class="code-block" style="font-size:16px;letter-spacing:1px">${escapeHtml(d.password)}</div>
      <div class="mt-2 flex items-center gap-2">
        <span class="badge" style="background:rgba(48,209,88,0.15);color:var(--green)">${escapeHtml(d.strength.level)}</span>
        <span class="text-sm text-secondary">Score: ${d.strength.score}/100</span>
        <button class="btn btn-glass btn-sm" onclick="navigator.clipboard.writeText('${escapeHtml(d.password)}');toast('Copied')">Copy</button>
      </div>`;
  } catch (_) {}
}

async function runPasswordStrength() {
  const password = $("#pwdCheck").value;
  if (!password) return toast("Enter a password", "error");
  try {
    const d = await api("/api/password/strength", "POST", { password });
    $("#pwdStrengthResult").innerHTML = `
      <div style="font-size:20px;font-weight:700;margin-bottom:8px">${escapeHtml(d.level)} · ${d.score}/100</div>
      <div class="text-sm text-secondary">${(d.feedback || []).map(escapeHtml).join(" · ") || "Good"}</div>`;
  } catch (_) {}
}


/* Bulk secure password generation */
let passwordBatch = [];
async function runPasswordBatch() {
  const count = Math.max(1, Math.min(2000, parseInt($("#pwdBatchCount").value || "1000", 10)));
  const body = {
    count,
    length: Math.max(12, parseInt($("#pwdLen").value, 10) || 20),
    use_upper: $("#pwdUpper").checked,
    use_lower: $("#pwdLower").checked,
    use_digits: $("#pwdDigit").checked,
    use_symbols: $("#pwdSymbol").checked
  };
  const btn = $("#pwdBatchBtn");
  setLoading(btn, true);
  try {
    const d = await api("/api/password/batch", "POST", body);
    passwordBatch = d.passwords || [];
    $("#pwdBatchResult").innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <strong>${passwordBatch.length.toLocaleString()} passwords generated</strong>
        <span class="badge badge-found">Ready</span>
      </div>
      <div class="code-block batch-preview">${passwordBatch.slice(0, 20).map(escapeHtml).join("\n")}${passwordBatch.length > 20 ? "\n…" : ""}</div>
      <div class="text-sm text-secondary mt-2">Showing the first 20. Use Download TXT or Copy All for the complete list.</div>`;
    toast("Password batch generated");
  } catch (_) {
    passwordBatch = [];
  } finally {
    setLoading(btn, false);
  }
}
function downloadPasswordBatch() {
  if (!passwordBatch.length) return toast("Generate a password list first", "error");
  const blob = new Blob([passwordBatch.join("\n")], {type:"text/plain;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "passwords.txt"; a.click();
  URL.revokeObjectURL(url);
}
async function copyPasswordBatch() {
  if (!passwordBatch.length) return toast("Generate a password list first", "error");
  try { await navigator.clipboard.writeText(passwordBatch.join("\n")); toast("Copied all passwords"); }
  catch (_) { toast("Clipboard access unavailable", "error"); }
}

/* Global chat — public IDs, no IP addresses displayed or stored in chat */
let chatIdentity = null;
let lastChatId = 0;
let chatPoller = null;
async function joinGlobalChat() {
  const username = $("#chatUsername").value.trim();
  if (username.length < 2) return toast("Enter a display name (at least 2 characters)", "error");
  const savedId = localStorage.getItem("darktrace_chat_id");
  try {
    chatIdentity = await api("/api/chat/register", "POST", {username, user_id:savedId});
    localStorage.setItem("darktrace_chat_id", chatIdentity.user_id);
    $("#chatUserId").textContent = chatIdentity.user_id;
    $("#chatUsername").value = chatIdentity.username;
    $("#chatUsername").disabled = true;
    $("#chatJoinBtn").textContent = "Joined";
    $("#chatJoinBtn").disabled = true;
    $("#chatMessageInput").focus();
    await refreshChat();
    if (chatPoller) clearInterval(chatPoller);
    chatPoller = setInterval(refreshChat, 2500);
    toast("Connected to Global Chat");
  } catch (_) {}
}
async function refreshChat() {
  if (!chatIdentity) return;
  try {
    const d = await api(`/api/chat/messages?after=${lastChatId}`);
    const box = $("#chatMessages");
    for (const m of (d.messages || [])) {
      const item = document.createElement("div");
      item.className = "chat-message";
      const meta = document.createElement("div");
      meta.className = "chat-meta";
      meta.textContent = `${m.username} · ${m.user_id} · ${m.created_at}`;
      const body = document.createElement("div");
      body.className = "chat-body";
      body.textContent = m.message;
      item.append(meta, body);
      box.appendChild(item);
      lastChatId = Math.max(lastChatId, m.id);
    }
    if (d.messages && d.messages.length) box.scrollTop = box.scrollHeight;
  } catch (_) {}
}
async function sendChatMessage() {
  if (!chatIdentity) return toast("Join the chat first", "error");
  const input = $("#chatMessageInput");
  const message = input.value.trim();
  if (!message) return;
  try {
    await api("/api/chat/messages", "POST", {user_id:chatIdentity.user_id, message});
    input.value = "";
    await refreshChat();
  } catch (_) {}
}
$("#chatMessageInput")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendChatMessage();
});
function showLicense() {
  alert("DARKTRACE LICENSE\n\nPersonal use. Do not use this platform to access accounts, systems, or data without authorization.");
}

/* Hash */
async function runHash() {
  const text = $("#hashText").value;
  const algorithm = $("#hashAlgo").value;
  if (!text) return toast("Enter text", "error");
  try {
    const d = await api("/api/hash/generate", "POST", { text, algorithm });
    let html = "";
    if (d.hash) {
      html = `<div class="code-block">${escapeHtml(d.hash)}</div>`;
    } else {
      html = Object.entries(d)
        .filter(([k]) => !["input", "algorithm"].includes(k))
        .map(([k, v]) => `<div class="mb-2"><div class="text-sm text-secondary">${k}</div><div class="code-block">${escapeHtml(v)}</div></div>`)
        .join("");
    }
    $("#hashResult").innerHTML = html;
  } catch (_) {}
}

async function runHashId() {
  const h = $("#hashIdInput").value.trim();
  if (!h) return toast("Enter a hash", "error");
  try {
    const d = await api("/api/hash/identify", "POST", { hash: h });
    $("#hashIdResult").innerHTML = (d.candidates || [])
      .map((c) => `<div class="glass-card result-card"><div class="result-title">${escapeHtml(c.type)}</div><div class="result-sub">Confidence: ${c.confidence} · Len: ${c.length}</div></div>`)
      .join("");
  } catch (_) {}
}

/* Base64 */
async function runB64Encode() {
  const text = $("#b64Text").value;
  try {
    const d = await api("/api/base64/encode", "POST", { text });
    $("#b64Result").innerHTML = `<div class="code-block">${escapeHtml(d.result)}</div>`;
  } catch (_) {}
}

async function runB64Decode() {
  const text = $("#b64Text").value;
  try {
    const d = await api("/api/base64/decode", "POST", { text });
    if (d.success) {
      $("#b64Result").innerHTML = `<div class="code-block">${escapeHtml(d.result)}</div>`;
    } else {
      toast(d.error || "Decode error", "error");
    }
  } catch (_) {}
}

/* Port scan */
async function runPortScan() {
  const target = $("#portTarget").value.trim() || "127.0.0.1";
  const box = $("#portResults");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div> Local scan...</div>`;
  try {
    const d = await api("/api/portscan", "POST", { target });
    if (d.error) {
      box.innerHTML = `<div class="glass-card result-card" style="color:var(--orange)">${escapeHtml(d.error)}</div>`;
      return;
    }
    if (!d.open_ports || !d.open_ports.length) {
      box.innerHTML = `<div class="glass-card result-card">No open ports found</div>`;
      return;
    }
    box.innerHTML = d.open_ports
      .map(
        (p) => `
      <div class="glass-card result-card">
        <div class="result-icon" style="background:rgba(48,209,88,0.15);color:var(--green)">${p.port}</div>
        <div class="result-body">
          <div class="result-title">Port ${p.port}</div>
          <div class="result-sub">${escapeHtml(p.service)}</div>
        </div>
        <span class="badge badge-found">Open</span>
      </div>`
      )
      .join("");
  } catch (e) {
    box.innerHTML = "";
  }
}

/* Learning */
async function loadLearn(type) {
  const box = $("#learnContent");
  box.innerHTML = `<div class="loading-overlay"><div class="spinner"></div></div>`;
  try {
    const d = await api(`/api/learn/${type}`);
    let html = `
      <div style="font-size:20px;font-weight:700;margin-bottom:8px">${escapeHtml(d.title)}</div>
      <div style="padding:12px;border-radius:12px;background:rgba(255,69,58,0.12);border:1px solid rgba(255,69,58,0.25);margin-bottom:16px;font-size:14px">${escapeHtml(d.warning)}</div>
      <p class="text-secondary" style="margin-bottom:16px">${escapeHtml(d.description || "")}</p>`;

    if (d.types) {
      html += `<h4 style="margin:12px 0 8px">Types</h4>`;
      d.types.forEach((t) => {
        html += `<div style="margin-bottom:10px"><strong>${escapeHtml(t.name)}</strong><div class="text-sm text-secondary">${escapeHtml(t.desc)}</div></div>`;
      });
    }
    if (d.payloads_examples) {
      html += `<h4 style="margin:16px 0 8px">Example payloads</h4>`;
      d.payloads_examples.forEach((p) => {
        html += `<div class="code-block" style="margin-bottom:8px">${escapeHtml(p.payload)} <span class="text-secondary">— ${escapeHtml(p.effect)}</span></div>`;
      });
    }
    if (d.examples) {
      html += `<h4 style="margin:16px 0 8px">Examples</h4>`;
      d.examples.forEach((p) => {
        html += `<div class="code-block" style="margin-bottom:8px">${escapeHtml(p.payload)} <span class="text-secondary">(${escapeHtml(p.context)})</span></div>`;
      });
    }
    if (d.prevention) {
      html += `<h4 style="margin:16px 0 8px">Prevention</h4><ul style="padding-left:18px;color:var(--text-secondary)">`;
      d.prevention.forEach((p) => (html += `<li style="margin-bottom:4px">${escapeHtml(p)}</li>`));
      html += `</ul>`;
    }
    if (d.safe_code_python) {
      html += `<h4 style="margin:16px 0 8px">Safe code</h4><div class="code-block">${escapeHtml(d.safe_code_python)}</div>`;
    }
    if (d.resources) {
      html += `<h4 style="margin:16px 0 8px">Resources</h4>`;
      d.resources.forEach((u) => {
        html += `<div><a href="${escapeHtml(u)}" target="_blank" rel="noopener" style="color:var(--accent);font-size:13px">${escapeHtml(u)}</a></div>`;
      });
    }
    box.innerHTML = html;
  } catch (e) {
    box.innerHTML = "Error";
  }
}

/* Global search filter */
$("#globalSearch")?.addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase();
  $$(".nav-item").forEach((item) => {
    const text = item.textContent.toLowerCase();
    item.style.display = !q || text.includes(q) ? "" : "none";
  });
});

/* Init */
document.addEventListener("DOMContentLoaded", () => {
  loadDashboard();
  // Enter key on username
  $("#usernameInput")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") runUsernameSearch();
  });
});
