"""
DARKTRACE — Ultimate OSINT & Cyber Intelligence Platform
Apple iOS 27 Liquid Glass Design
"""
import asyncio
import json
import sqlite3
import secrets
import re
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
import uvicorn

from config import HOST, PORT, DEBUG, DATABASE_PATH, USERNAME_PLATFORMS
from tools import crypto_tools, osint_tools, security_tools

app = FastAPI(
    title="DARKTRACE",
    description="Ultimate OSINT & Cyber Intelligence Platform — iOS 27 Liquid Glass",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url=None,
)

BASE = Path(__file__).parent
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
templates = Jinja2Templates(directory=BASE / "templates")


# ---------- Database ----------
def init_db():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tool TEXT NOT NULL,
            query TEXT,
            result_summary TEXT,
            ip TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chat_users (
            user_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def log_activity(tool: str, query: str = "", summary: str = "", ip: str = ""):
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.execute(
            "INSERT INTO activity (tool, query, result_summary, ip) VALUES (?, ?, ?, ?)",
            (tool, query[:200], summary[:300], ip[:50]),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def get_recent_activity(limit: int = 20):
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM activity ORDER BY created_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


init_db()


# ---------- Models ----------
class PasswordRequest(BaseModel):
    length: int = Field(16, ge=4, le=128)
    use_upper: bool = True
    use_lower: bool = True
    use_digits: bool = True
    use_symbols: bool = True
    exclude_ambiguous: bool = True


class PasswordBatchRequest(BaseModel):
    count: int = Field(1000, ge=1, le=2000)
    length: int = Field(20, ge=12, le=128)
    use_upper: bool = True
    use_lower: bool = True
    use_digits: bool = True
    use_symbols: bool = True


class ChatRegisterRequest(BaseModel):
    username: str = Field(..., min_length=2, max_length=24)
    user_id: Optional[str] = None


class ChatMessageRequest(BaseModel):
    user_id: str
    message: str = Field(..., min_length=1, max_length=500)


class HashRequest(BaseModel):
    text: str
    algorithm: str = "sha256"


class UsernameRequest(BaseModel):
    username: str
    platforms: Optional[List[str]] = None


class MultiUsernameRequest(BaseModel):
    usernames: List[str]


class DomainRequest(BaseModel):
    domain: str


class IPRequest(BaseModel):
    ip: str


class URLRequest(BaseModel):
    url: str


class PortScanRequest(BaseModel):
    target: str = "127.0.0.1"
    ports: Optional[List[int]] = None


# ---------- API Routes ----------
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/health")
async def health():
    return {"status": "ok", "platform": "DARKTRACE", "version": "1.0.0"}


@app.get("/api/dashboard")
async def dashboard(request: Request):
    recent = get_recent_activity(12)
    return {
        "welcome": "Welcome to DARKTRACE",
        "total_tools": 28,
        "osint_tools": 14,
        "cyber_tools": 14,
        "recent_activity": recent,
        "system_status": "online",
        "platforms_count": len(USERNAME_PLATFORMS),
    }


@app.get("/api/platforms")
async def list_platforms():
    return {"platforms": [{"name": p["name"], "icon": p.get("icon")} for p in USERNAME_PLATFORMS]}


# ---- Crypto ----
@app.post("/api/password/generate")
async def api_password_generate(req: PasswordRequest, request: Request):
    pwd = crypto_tools.generate_password(
        req.length, req.use_upper, req.use_lower, req.use_digits, req.use_symbols, req.exclude_ambiguous
    )
    strength = crypto_tools.check_password_strength(pwd)
    log_activity("password_generate", str(req.length), "generated", request.client.host if request.client else "")
    return {"password": pwd, "strength": strength}


@app.post("/api/password/strength")
async def api_password_strength(data: dict, request: Request):
    password = data.get("password", "")
    result = crypto_tools.check_password_strength(password)
    log_activity("password_strength", "****", result["level"], request.client.host if request.client else "")
    return result


@app.post("/api/password/batch")
async def api_password_batch(req: PasswordBatchRequest):
    # Independent cryptographically-random passwords; never derived from a username.
    passwords = [
        crypto_tools.generate_password(
            req.length, req.use_upper, req.use_lower, req.use_digits, req.use_symbols, True
        )
        for _ in range(req.count)
    ]
    return {"count": len(passwords), "passwords": passwords}


@app.post("/api/chat/register")
async def chat_register(req: ChatRegisterRequest):
    username = req.username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,24}", username):
        raise HTTPException(status_code=400, detail="Use 2–24 letters, numbers, dots, underscores or hyphens.")
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    user_id = (req.user_id or "").strip()
    existing = conn.execute("SELECT user_id, username FROM chat_users WHERE user_id=?", (user_id,)).fetchone() if user_id else None
    if existing:
        conn.execute("UPDATE chat_users SET username=? WHERE user_id=?", (username, user_id))
    else:
        user_id = "DT-" + secrets.token_hex(4).upper()
        conn.execute("INSERT INTO chat_users(user_id, username) VALUES (?, ?)", (user_id, username))
    conn.commit()
    conn.close()
    return {"user_id": user_id, "username": username}


@app.get("/api/chat/messages")
async def chat_messages(after: int = 0):
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, user_id, username, message, created_at FROM chat_messages WHERE id>? ORDER BY id DESC LIMIT 100",
        (after,)
    ).fetchall()
    conn.close()
    return {"messages": [dict(r) for r in reversed(rows)]}


@app.post("/api/chat/messages")
async def chat_send(req: ChatMessageRequest):
    message = req.message.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    user = conn.execute("SELECT user_id, username FROM chat_users WHERE user_id=?", (req.user_id,)).fetchone()
    if not user:
        conn.close()
        raise HTTPException(status_code=401, detail="Register your chat identity first.")
    cur = conn.execute(
        "INSERT INTO chat_messages(user_id, username, message) VALUES (?, ?, ?)",
        (user["user_id"], user["username"], message[:500])
    )
    msg_id = cur.lastrowid
    row = conn.execute("SELECT id, user_id, username, message, created_at FROM chat_messages WHERE id=?", (msg_id,)).fetchone()
    conn.commit()
    conn.close()
    return dict(row)


@app.post("/api/hash/generate")
async def api_hash(req: HashRequest, request: Request):
    result = crypto_tools.generate_hash(req.text, req.algorithm)
    log_activity("hash", req.algorithm, "ok", request.client.host if request.client else "")
    return result


@app.post("/api/hash/identify")
async def api_hash_identify(data: dict):
    h = data.get("hash", "")
    return {"candidates": crypto_tools.identify_hash(h)}


@app.post("/api/base64/encode")
async def api_b64_encode(data: dict):
    return {"result": crypto_tools.base64_encode(data.get("text", ""))}


@app.post("/api/base64/decode")
async def api_b64_decode(data: dict):
    return crypto_tools.base64_decode(data.get("text", ""))


@app.get("/api/totp/generate")
async def api_totp():
    return crypto_tools.generate_totp_secret()


# ---- OSINT ----
@app.post("/api/username/search")
async def api_username(req: UsernameRequest, request: Request):
    results = await osint_tools.check_username(req.username, req.platforms)
    found = sum(1 for r in results if r.get("status") == "found")
    log_activity("username_search", req.username, f"found:{found}", request.client.host if request.client else "")
    return {"username": req.username, "results": results, "found_count": found}


@app.post("/api/username/multi")
async def api_multi_username(req: MultiUsernameRequest, request: Request):
    results = await osint_tools.multi_username_search(req.usernames)
    log_activity("multi_username", ",".join(req.usernames)[:80], "done", request.client.host if request.client else "")
    return {"results": results}


@app.post("/api/ip/lookup")
async def api_ip(req: IPRequest, request: Request):
    data = await osint_tools.ip_lookup(req.ip)
    log_activity("ip_lookup", req.ip, data.get("country", ""), request.client.host if request.client else "")
    return data


@app.post("/api/domain/whois")
async def api_whois(req: DomainRequest, request: Request):
    data = await osint_tools.domain_whois(req.domain)
    log_activity("whois", req.domain, data.get("registrar", "") or "", request.client.host if request.client else "")
    return data


@app.post("/api/domain/dns")
async def api_dns(data: dict, request: Request):
    domain = data.get("domain", "")
    rtype = data.get("type", "A")
    result = await osint_tools.dns_lookup(domain, rtype)
    log_activity("dns", f"{domain}/{rtype}", str(len(result.get("records", []))), request.client.host if request.client else "")
    return result


@app.post("/api/domain/subdomains")
async def api_subdomains(req: DomainRequest, request: Request):
    data = await osint_tools.subdomain_discovery(req.domain)
    log_activity("subdomains", req.domain, f"found:{len(data.get('found', []))}", request.client.host if request.client else "")
    return data


@app.post("/api/url/headers")
async def api_headers(req: URLRequest, request: Request):
    data = await osint_tools.http_headers(req.url)
    log_activity("headers", req.url[:80], str(data.get("status_code", "")), request.client.host if request.client else "")
    return data


@app.post("/api/url/ssl")
async def api_ssl(req: DomainRequest, request: Request):
    data = await osint_tools.ssl_check(req.domain)
    log_activity("ssl", req.domain, "ok" if "error" not in data else "err", request.client.host if request.client else "")
    return data


@app.post("/api/url/analyze")
async def api_analyze(req: URLRequest, request: Request):
    data = await osint_tools.website_analyzer(req.url)
    log_activity("analyze", req.url[:80], data.get("title", "")[:40], request.client.host if request.client else "")
    return data


# ---- Security / Education ----
@app.post("/api/portscan")
async def api_portscan(req: PortScanRequest, request: Request):
    data = security_tools.port_scan_local(req.target, req.ports)
    log_activity("portscan", req.target, f"open:{data.get('open_count', 0)}", request.client.host if request.client else "")
    return data


@app.post("/api/security/headers")
async def api_sec_headers(data: dict):
    headers = data.get("headers", {})
    return security_tools.security_headers_analyze(headers)


@app.get("/api/learn/sqli")
async def api_sqli():
    return security_tools.sql_injection_learning()


@app.get("/api/learn/xss")
async def api_xss():
    return security_tools.xss_learning()


@app.get("/api/uuid")
async def api_uuid():
    return security_tools.generate_uuid()


@app.get("/api/activity")
async def api_activity(limit: int = 20):
    return {"activity": get_recent_activity(limit)}


# ---------- Run ----------
if __name__ == "__main__":
    print(f"""
    ╔══════════════════════════════════════════════╗
    ║           D A R K T R A C E                  ║
    ║   Ultimate OSINT & Cyber Intelligence        ║
    ║   Design: Apple iOS 27 Liquid Glass          ║
    ╚══════════════════════════════════════════════╝
    → http://{HOST}:{PORT}
    """)
    uvicorn.run("app:app", host=HOST, port=PORT, reload=DEBUG)
