import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
DEBUG = os.getenv("DEBUG", "true").lower() == "true"
SECRET_KEY = os.getenv("SECRET_KEY", "darktrace-dev-secret-change-me-in-production-please")

# Optional API keys
IPINFO_TOKEN = os.getenv("IPINFO_TOKEN", "")
WHOISXML_API_KEY = os.getenv("WHOISXML_API_KEY", "")
SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "")
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")

DATABASE_PATH = DATA_DIR / "darktrace.db"

# Username search platforms (curated public checks)
USERNAME_PLATFORMS = [
    {"name": "GitHub", "url": "https://github.com/{}", "check": "status", "icon": "github"},
    {"name": "GitLab", "url": "https://gitlab.com/{}", "check": "status", "icon": "gitlab"},
    {"name": "Reddit", "url": "https://www.reddit.com/user/{}", "check": "status", "icon": "reddit"},
    {"name": "Twitter / X", "url": "https://x.com/{}", "check": "status", "icon": "twitter"},
    {"name": "Instagram", "url": "https://www.instagram.com/{}", "check": "status", "icon": "instagram"},
    {"name": "TikTok", "url": "https://www.tiktok.com/@{}", "check": "status", "icon": "tiktok"},
    {"name": "YouTube", "url": "https://www.youtube.com/@{}", "check": "status", "icon": "youtube"},
    {"name": "Twitch", "url": "https://www.twitch.tv/{}", "check": "status", "icon": "twitch"},
    {"name": "Steam", "url": "https://steamcommunity.com/id/{}", "check": "status", "icon": "steam"},
    {"name": "Pinterest", "url": "https://www.pinterest.com/{}", "check": "status", "icon": "pinterest"},
    {"name": "Medium", "url": "https://medium.com/@{}", "check": "status", "icon": "medium"},
    {"name": "Dev.to", "url": "https://dev.to/{}", "check": "status", "icon": "devto"},
    {"name": "HackerNews", "url": "https://news.ycombinator.com/user?id={}", "check": "status", "icon": "hackernews"},
    {"name": "Keybase", "url": "https://keybase.io/{}", "check": "status", "icon": "keybase"},
    {"name": "About.me", "url": "https://about.me/{}", "check": "status", "icon": "aboutme"},
    {"name": "SoundCloud", "url": "https://soundcloud.com/{}", "check": "status", "icon": "soundcloud"},
    {"name": "Spotify", "url": "https://open.spotify.com/user/{}", "check": "status", "icon": "spotify"},
    {"name": "Telegram", "url": "https://t.me/{}", "check": "status", "icon": "telegram"},
    {"name": "VK", "url": "https://vk.com/{}", "check": "status", "icon": "vk"},
    {"name": "LinkedIn", "url": "https://www.linkedin.com/in/{}", "check": "status", "icon": "linkedin"},
    {"name": "Facebook", "url": "https://www.facebook.com/{}", "check": "status", "icon": "facebook"},
    {"name": "Snapchat", "url": "https://www.snapchat.com/add/{}", "check": "status", "icon": "snapchat"},
    {"name": "Discord", "url": "https://discord.com/users/{}", "check": "manual", "icon": "discord"},
    {"name": "Pastebin", "url": "https://pastebin.com/u/{}", "check": "status", "icon": "pastebin"},
    {"name": "Replit", "url": "https://replit.com/@{}", "check": "status", "icon": "replit"},
]

RATE_LIMIT = int(os.getenv("RATE_LIMIT", "60"))
